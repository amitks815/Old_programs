"""This is a chennai"""

def Chennai():
	print "Tamilnadu capital is Chennai"
	

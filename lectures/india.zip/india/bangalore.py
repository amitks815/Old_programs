"""This is a Bangalore"""

def Bangalore():
	print "Karnataka capital is Bangalore"
	

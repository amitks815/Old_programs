"""This is a Hyderabad"""

def Hyderabad():
	print "Telungana capital is Hyderabad"
	

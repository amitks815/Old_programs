"""This is init file which contains all modules"""

from chennai import Chennai
from bangalore import Bangalore
from hyderabad import Hyderabad
